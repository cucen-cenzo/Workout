# RepCounter
Android app that counts push-ups, sit-ups and squats using the camera and on-device pose detection (ML Kit). Shows a skeleton overlay and a range slider on the left.

## Get the APK
- Every push to `main`: Actions tab → latest run → **RepCounter-apk** artifact.
- Release: `git tag v1.0 && git push --tags` → APK is attached to the GitHub Release.

## Use
Prop the phone ~2 m away, side-on for push-ups/sit-ups. Pick an exercise at the bottom. Switching resets the count.

Tune thresholds in `RepCounter.kt` (`open` / `closed` angles).
