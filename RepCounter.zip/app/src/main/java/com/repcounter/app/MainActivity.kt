package com.repcounter.app

import android.Manifest
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.accurate.AccuratePoseDetectorOptions
import java.util.concurrent.Executors

@androidx.annotation.OptIn(ExperimentalGetImage::class)
class MainActivity : ComponentActivity() {
    private val counter = RepCounter()
    private lateinit var ov: OverlayView
    private lateinit var preview: PreviewView
    private lateinit var root: FrameLayout
    private var historyView: View? = null
    private val bg = 0xFF040810.toInt()
    private val exec = Executors.newSingleThreadExecutor()
    private val detector = PoseDetection.getClient(
        AccuratePoseDetectorOptions.Builder().setDetectorMode(AccuratePoseDetectorOptions.STREAM_MODE).build())
    private val perm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) startCamera() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = bg; window.navigationBarColor = bg
        val store = Store(this)
        counter.onRep = { store.add(it) }
        val settings = Settings(this)
        Exercise.values().forEach { counter.depth[it.ordinal] = settings.depth(it) / 100f }
        preview = PreviewView(this)
        ov = OverlayView(this, counter).apply {
            onSelect = { counter.exercise = it; invalidate() }
            onHistory = { showHistory(store) }
            onSettings = { showSettings(settings) }
        }
        root = FrameLayout(this).apply { setBackgroundColor(bg) }
        root.addView(preview, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        root.addView(ov, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        setContentView(root)
        onBackPressedDispatcher.addCallback(this) { if (historyView != null) closeHistory() else finish() }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else perm.launch(Manifest.permission.CAMERA)
    }

    private fun tv(t: String, size: Float, col: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(col); if (bold) typeface = Typeface.DEFAULT_BOLD; setPadding(0, 4, 0, 4)
    }

    private fun closeHistory() { historyView?.let { root.removeView(it) }; historyView = null }

    private fun showHistory(store: Store) {
        if (historyView != null) return
        val dp = resources.displayMetrics.density; val pad = (18 * dp).toInt()
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, 0, pad, pad * 2) }
        val days = store.days()
        if (days.isEmpty()) list.addView(tv("No workouts yet. Finish a rep and it is saved here.", 16f, 0xFF7A8BB5.toInt()))
        for ((date, m) in days) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad)
                background = GradientDrawable().apply { setColor(0x22FFFFFF); cornerRadius = 18 * dp; setStroke(dp.toInt(), 0x554DA3FF) }
            }
            card.addView(tv(dayLabel(date), 18f, Color.WHITE, true))
            Exercise.values().forEach { e -> val n = m[e] ?: 0; if (n > 0) card.addView(tv("${e.label}  ·  $n reps", 15f, 0xFF9DB4E0.toInt())) }
            list.addView(card, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = pad })
        }
        val head = LinearLayout(this).apply { setPadding(pad, pad * 2, pad, pad); gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("History", 28f, Color.WHITE, true), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        head.addView(tv("✕", 26f, Color.WHITE).apply { setOnClickListener { closeHistory() } })
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); isClickable = true }
        page.addView(head); page.addView(ScrollView(this).apply { addView(list) })
        root.addView(page, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)); historyView = page
    }

    private fun showSettings(st: Settings) {
        if (historyView != null) return
        val dp = resources.displayMetrics.density; val pad = (18 * dp).toInt()
        val blue = 0xFF2E8BFF.toInt()
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, 0, pad, pad * 2) }
        list.addView(tv("Rep depth: lower means shorter reps still count. Great for beginners.", 15f, 0xFF7A8BB5.toInt()))
        Exercise.values().forEach { e ->
            val lab = tv("", 18f, Color.WHITE, true)
            fun show(p: Int) { lab.text = "${e.label}: $p%  (${if (p <= 50) "short reps" else if (p <= 80) "medium" else "full reps"})" }
            val cur = st.depth(e); show(cur)
            val bar = SeekBar(this).apply {
                max = 65; progress = cur - 35
                thumbTintList = ColorStateList.valueOf(blue); progressTintList = ColorStateList.valueOf(blue)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                        val v = p + 35; show(v); st.setDepth(e, v); counter.depth[e.ordinal] = v / 100f
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            list.addView(lab, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = pad })
            list.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }
        val head = LinearLayout(this).apply { setPadding(pad, pad * 2, pad, pad); gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("Settings", 28f, Color.WHITE, true), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        head.addView(tv("\u2715", 26f, Color.WHITE).apply { setOnClickListener { closeHistory() } })
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); isClickable = true }
        page.addView(head); page.addView(ScrollView(this).apply { addView(list) })
        root.addView(page, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)); historyView = page
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val prev = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val ana = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            ana.setAnalyzer(exec) { proxy ->
                val img = proxy.image
                if (img == null) { proxy.close(); return@setAnalyzer }
                val rot = proxy.imageInfo.rotationDegrees
                val w = if (rot % 180 == 0) proxy.width else proxy.height
                val h = if (rot % 180 == 0) proxy.height else proxy.width
                detector.process(InputImage.fromMediaImage(img, rot))
                    .addOnSuccessListener { pose -> counter.update(pose, w, h, android.os.SystemClock.uptimeMillis()); ov.setSize(w, h) }
                    .addOnCompleteListener { proxy.close() }
            }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, prev, ana)
        }, ContextCompat.getMainExecutor(this))
    }
}
