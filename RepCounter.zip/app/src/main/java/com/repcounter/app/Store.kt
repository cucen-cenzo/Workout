package com.repcounter.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Saves every rep immediately, per day + exercise, in app storage.
class Store(c: Context) {
    private val sp = c.getSharedPreferences("history", Context.MODE_PRIVATE)
    private val f = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun add(e: Exercise) {
        val k = "${f.format(Date())}:${e.name}"
        sp.edit().putInt(k, sp.getInt(k, 0) + 1).apply()
    }

    fun days(): List<Pair<String, Map<Exercise, Int>>> =
        sp.all.entries
            .groupBy({ it.key.substringBefore(':') }, { Exercise.valueOf(it.key.substringAfter(':')) to (it.value as Int) })
            .toSortedMap(reverseOrder())
            .map { (d, l) -> d to l.toMap() }
}

fun dayLabel(date: String): String {
    val f = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    if (date == f.format(Date())) return "Today"
    if (date == f.format(Date(System.currentTimeMillis() - 86400000L))) return "Yesterday"
    return SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(f.parse(date)!!)
}

// Rep depth per exercise, in percent of a full rep (lower = shorter reps still count).
class Settings(c: Context) {
    private val sp = c.getSharedPreferences("settings", Context.MODE_PRIVATE)
    fun depth(e: Exercise) = sp.getInt("depth_${e.name}", 100)
    fun setDepth(e: Exercise, pct: Int) = sp.edit().putInt("depth_${e.name}", pct).apply()
}
