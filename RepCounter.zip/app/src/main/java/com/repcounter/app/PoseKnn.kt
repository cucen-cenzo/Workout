package com.repcounter.app

import android.content.Context
import android.os.SystemClock
import com.google.mlkit.vision.pose.Pose
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/*
 * k-NN pose classifier, ported to Kotlin from Google's ML Kit vision quickstart
 * (PoseClassifier, PoseEmbedding, PoseSample, EMASmoothing).
 * Copyright 2020 Google LLC. Licensed under the Apache License, Version 2.0
 * (http://www.apache.org/licenses/LICENSE-2.0). Modified: Kotlin port, flat arrays, slower smoothing reset.
 *
 * Compares the live pose with recorded example poses in assets/pose/fitness_pose_samples.csv
 * and returns, per class, how many of the 10 nearest examples belong to it (smoothed).
 */
class PoseKnn(context: Context) {
    private val classes = ArrayList<String>()
    private val samples = ArrayList<FloatArray>()
    private val window = ArrayDeque<Map<String, Float>>()
    private var lastMs = 0L
    private val wgt = floatArrayOf(1f, 1f, 0.2f)   // z is less accurate, so it counts less
    val ready: Boolean

    init {
        try {
            context.assets.open("pose/fitness_pose_samples.csv").bufferedReader().useLines { lines ->
                for (line in lines) {
                    val t = line.split(',')
                    if (t.size != 33 * 3 + 2) continue        // Name,Class,X1,Y1,Z1,...
                    val raw = FloatArray(99)
                    var bad = false
                    for (i in 0 until 99) { val v = t[i + 2].toFloatOrNull(); if (v == null) { bad = true; break }; raw[i] = v }
                    if (bad) continue
                    classes.add(t[1]); samples.add(embed(raw))
                }
            }
        } catch (e: Exception) { /* no samples file: app falls back to its own geometry */ }
        ready = samples.isNotEmpty()
    }

    // translation + scale normalisation, then 23 pairwise landmark differences (as in Google's PoseEmbedding)
    private fun embed(raw: FloatArray): FloatArray {
        val p = raw.copyOf()
        val cx = (p[69] + p[72]) / 2; val cy = (p[70] + p[73]) / 2; val cz = (p[71] + p[74]) / 2   // hips (23, 24)
        for (i in 0 until 33) { p[i * 3] -= cx; p[i * 3 + 1] -= cy; p[i * 3 + 2] -= cz }
        val sx = (p[33] + p[36]) / 2; val sy = (p[34] + p[37]) / 2                                   // shoulders (11, 12)
        var size = hypot(sx, sy) * 2.5f
        for (i in 0 until 33) size = max(size, hypot(p[i * 3], p[i * 3 + 1]))
        if (size < 1e-3f) return FloatArray(69)
        val f = 100f / size
        for (i in p.indices) p[i] *= f
        val out = FloatArray(69); var o = 0
        fun sub(a: Int, b: Int) { for (k in 0..2) out[o++] = p[b * 3 + k] - p[a * 3 + k] }
        for (k in 0..2) out[o++] = (p[33 + k] + p[36 + k]) / 2 - (p[69 + k] + p[72 + k]) / 2
        sub(11, 13); sub(12, 14); sub(13, 15); sub(14, 16); sub(23, 25); sub(24, 26); sub(25, 27); sub(26, 28)
        sub(11, 15); sub(12, 16); sub(23, 27); sub(24, 28)
        sub(23, 15); sub(24, 16)
        sub(11, 27); sub(12, 28); sub(23, 15); sub(24, 16)
        sub(13, 14); sub(25, 26); sub(15, 16); sub(27, 28)
        return out
    }

    private fun smallest(d: FloatArray, k: Int): IntArray {
        val kk = min(k, d.size)
        val idx = IntArray(kk) { -1 }; val v = FloatArray(kk) { Float.MAX_VALUE }
        for (i in d.indices) {
            val x = d[i]
            if (kk == 0 || x >= v[kk - 1]) continue
            var j = kk - 1
            while (j > 0 && v[j - 1] > x) { v[j] = v[j - 1]; idx[j] = idx[j - 1]; j-- }
            v[j] = x; idx[j] = i
        }
        return idx.filter { it >= 0 }.toIntArray()
    }

    private fun classifyRaw(raw: FloatArray): Map<String, Float> {
        val e1 = embed(raw)
        val flipped = raw.copyOf(); for (i in 0 until 33) flipped[i * 3] = -flipped[i * 3]   // mirror-invariant
        val e2 = embed(flipped)
        val n = samples.size
        val maxD = FloatArray(n)
        for (s in 0 until n) {                       // stage 1: closest 30 by worst-joint distance (drops outliers)
            val sm = samples[s]; var m1 = 0f; var m2 = 0f
            for (i in 0 until 69) {
                val w = wgt[i % 3]
                m1 = max(m1, abs(e1[i] - sm[i]) * w); m2 = max(m2, abs(e2[i] - sm[i]) * w)
            }
            maxD[s] = min(m1, m2)
        }
        val cand = smallest(maxD, 30)
        val meanD = FloatArray(cand.size)
        for ((ci, s) in cand.withIndex()) {          // stage 2: closest 10 by mean distance
            val sm = samples[s]; var s1 = 0f; var s2 = 0f
            for (i in 0 until 69) { val w = wgt[i % 3]; s1 += abs(e1[i] - sm[i]) * w; s2 += abs(e2[i] - sm[i]) * w }
            meanD[ci] = min(s1, s2) / (23 * 2)
        }
        val res = HashMap<String, Float>()
        for (bi in smallest(meanD, 10)) { val cls = classes[cand[bi]]; res[cls] = (res[cls] ?: 0f) + 1f }
        return res
    }

    /** Smoothed class confidences (0..10). Call from ONE background thread. */
    fun classify(pose: Pose): Map<String, Float> {
        if (!ready) return emptyMap()
        val now = SystemClock.elapsedRealtime()
        if (now - lastMs > 500) window.clear()
        lastMs = now
        val lms = pose.allPoseLandmarks
        val cur: Map<String, Float> = if (lms.size < 33) emptyMap() else {
            val raw = FloatArray(99)
            for (l in lms) { val t = l.landmarkType; if (t in 0..32) { val q = l.position3D; raw[t * 3] = q.x; raw[t * 3 + 1] = q.y; raw[t * 3 + 2] = q.z } }
            classifyRaw(raw)
        }
        if (window.size == 10) window.removeLast()
        window.addFirst(cur)
        val names = HashSet<String>(); for (r in window) names.addAll(r.keys)
        val out = HashMap<String, Float>()
        for (nm in names) {                           // exponential moving average over the window
            var factor = 1f; var top = 0f; var bottom = 0f
            for (r in window) { top += factor * (r[nm] ?: 0f); bottom += factor; factor *= 0.8f }
            out[nm] = top / bottom
        }
        return out
    }
}
