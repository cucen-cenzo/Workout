package com.repcounter.app

import android.content.Context
import android.graphics.*
import android.view.View
import com.google.mlkit.vision.pose.Pose
import kotlin.math.max

class OverlayView(c: Context, private val rc: RepCounter) : View(c) {
    private var pose: Pose? = null
    private var iw = 1; private var ih = 1
    private val t0 = System.currentTimeMillis()
    private val d = resources.displayMetrics.density
    private val orange = 0xFFF5A623.toInt()
    private val bone = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeWidth = 4 * d; strokeCap = Paint.Cap.ROUND }
    private val joint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = orange }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66FFFFFF; strokeWidth = 14 * d; strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = orange; strokeWidth = 14 * d; strokeCap = Paint.Cap.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD; setShadowLayer(8f, 0f, 0f, Color.BLACK) }
    private val bones = listOf(11 to 12, 11 to 13, 13 to 15, 12 to 14, 14 to 16, 11 to 23, 12 to 24, 23 to 24, 23 to 25, 25 to 27, 24 to 26, 26 to 28)

    fun setPose(p: Pose, w: Int, h: Int) { pose = p; iw = w; ih = h; invalidate() }

    override fun onDraw(cv: Canvas) {
        val s = max(width / iw.toFloat(), height / ih.toFloat())
        val dx = (width - iw * s) / 2; val dy = (height - ih * s) / 2
        // front camera preview is mirrored, so mirror x
        fun pt(i: Int) = pose?.getPoseLandmark(i)?.takeIf { it.inFrameLikelihood > 0.5f }
            ?.position?.let { PointF((iw - it.x) * s + dx, it.y * s + dy) }
        for ((a, b) in bones) { val p = pt(a); val q = pt(b); if (p != null && q != null) cv.drawLine(p.x, p.y, q.x, q.y, bone) }
        for (i in 11..28) pt(i)?.let { cv.drawCircle(it.x, it.y, 6 * d, joint) }

        // range slider on the left: fills as you move through the rep
        val x = 32 * d; val top = height * 0.3f; val bot = height * 0.7f
        cv.drawLine(x, top, x, bot, track)
        if (rc.progress > 0.02f) cv.drawLine(x, bot, x, bot - (bot - top) * rc.progress, fill)

        txt.textSize = 80 * d; cv.drawText("${rc.reps}", 20 * d, 110 * d, txt)
        txt.textSize = 18 * d
        val sec = (System.currentTimeMillis() - t0) / 1000
        cv.drawText("${rc.exercise.label}  %d:%02d".format(sec / 60, sec % 60), 24 * d, 140 * d, txt)
    }
}
