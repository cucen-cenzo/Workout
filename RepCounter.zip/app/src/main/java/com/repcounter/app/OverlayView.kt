package com.repcounter.app

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.max

class OverlayView(c: Context, private val rc: RepCounter) : View(c) {
    private var iw = 1; private var ih = 1
    private val d = resources.displayMetrics.density
    private val orange = 0xFFF5A623.toInt()
    private fun p(col: Int, sw: Float = 0f, st: Paint.Style = Paint.Style.FILL) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col; strokeWidth = sw * d; strokeCap = Paint.Cap.ROUND; style = st }
    private val bone = p(0xCCFFFFFF.toInt(), 3f); private val dot = p(Color.WHITE)
    private val track = p(0x55FFFFFF, 14f); private val fill = p(orange, 14f)
    private val ghost = p(0x66FFFFFF, 20f); private val panel = p(0x33FFFFFF)
    private val disc = p(0x77000000); private val ring = p(0xCCFFFFFF.toInt(), 5f, Paint.Style.STROKE)
    private val txt = p(Color.WHITE).apply { typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER; setShadowLayer(8f, 0f, 0f, Color.BLACK) }
    private val bones = listOf(11 to 12, 11 to 13, 13 to 15, 12 to 14, 14 to 16, 11 to 23, 12 to 24, 23 to 24, 23 to 25, 25 to 27, 24 to 26, 26 to 28)
    private val joints = intArrayOf(11, 12, 13, 14, 15, 16, 23, 24, 25, 26, 27, 28)

    fun setSize(w: Int, h: Int) { iw = w; ih = h; invalidate() }

    override fun onDraw(cv: Canvas) {
        val s = max(width / iw.toFloat(), height / ih.toFloat())
        val dx = (width - iw * s) / 2; val dy = (height - ih * s) / 2
        fun X(i: Int) = (iw - rc.x[i]) * s + dx   // mirrored like the front-camera preview
        fun Y(i: Int) = rc.y[i] * s + dy
        for ((a, b) in bones) if (rc.vis[a] && rc.vis[b]) cv.drawLine(X(a), Y(a), X(b), Y(b), bone)
        for (i in joints) if (rc.vis[i]) cv.drawCircle(X(i), Y(i), 5 * d, dot)

        if (rc.state == State.WAIT) {   // body guide
            val cx = width / 2f; val top = height * 0.2f; val bt = height * 0.78f; val u = (bt - top) / 10
            cv.drawRoundRect(RectF(width * 0.22f, top, width * 0.78f, bt), 24 * d, 24 * d, panel)
            cv.drawCircle(cx, top + u, u * 0.6f, panel.apply { alpha = 0x66 })
            cv.drawLine(cx, top + 2 * u, cx, top + 5.2f * u, ghost)
            cv.drawLine(cx, top + 2.4f * u, cx - 1.4f * u, top + 5 * u, ghost)
            cv.drawLine(cx, top + 2.4f * u, cx + 1.4f * u, top + 5 * u, ghost)
            cv.drawLine(cx, top + 5.2f * u, cx - 0.6f * u, top + 9.2f * u, ghost)
            cv.drawLine(cx, top + 5.2f * u, cx + 0.6f * u, top + 9.2f * u, ghost)
        }
        // range slider (left): orange rises as you go through a full rep
        val sx = 28 * d; val top = height * 0.3f; val bot = height * 0.7f
        cv.drawLine(sx, top, sx, bot, track)
        if (rc.effort > 0.03f) cv.drawLine(sx, bot, sx, bot - (bot - top) * rc.effort, fill)

        // counter circle: countdown first, then reps
        val cx = 84 * d; val cy = 120 * d
        cv.drawCircle(cx, cy, 56 * d, disc); cv.drawCircle(cx, cy, 56 * d, ring)
        txt.textSize = 56 * d
        cv.drawText("${if (rc.state == State.COUNTDOWN) rc.countdown else rc.reps}", cx, cy + 20 * d, txt)
        txt.textSize = 16 * d; cv.drawText(rc.exercise.label, cx, cy + 82 * d, txt)

        val m = rc.message
        if (m.isNotEmpty()) {
            txt.textSize = 20 * d
            val mid = m.indexOf(' ', m.length / 2)
            val lines = if (mid > 0) listOf(m.substring(0, mid), m.substring(mid + 1)) else listOf(m)
            lines.forEachIndexed { i, t -> cv.drawText(t, width / 2f, height - 150 * d + i * 26 * d, txt) }
        }
    }
}
