package com.repcounter.app

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max

class OverlayView(c: Context, private val rc: RepCounter) : View(c) {
    var onSelect: (Exercise) -> Unit = {}
    var onHistory: () -> Unit = {}
    var onSettings: () -> Unit = {}
    private var iw = 1; private var ih = 1
    private val d = resources.displayMetrics.density
    private val blue = 0xFF2E8BFF.toInt(); private val orange = 0xFFF5A623.toInt(); private val navy = 0xFF0A1B3D.toInt()
    private val muted = 0xFF7A8BB5.toInt(); private val ice = 0xFF7CC4FF.toInt(); private val gray = 0xFFB0B8C8.toInt()
    private val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }
    private val rf = RectF()
    private val round = CornerPathEffect(7f * d)
    private val path = Path()
    private val bGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x442E8BFF; strokeWidth = 9 * d; strokeJoin = Paint.Join.ROUND; pathEffect = round }
    private val bFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = navy; pathEffect = round }
    private val bEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = blue; strokeWidth = 2 * d; strokeJoin = Paint.Join.ROUND; pathEffect = round }
    private val bSheen = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0x663C9CFF; pathEffect = round }

    private fun pen(col: Int, sw: Number = 0, st: Paint.Style = Paint.Style.STROKE): Paint { sp.color = col; sp.strokeWidth = sw.toFloat() * d; sp.style = st; return sp }
    private fun fillP(col: Int) = pen(col, 0f, Paint.Style.FILL)
    private fun soft(col: Int) = (col and 0xFFFFFF) or 0x33000000
    private fun text(cv: Canvas, t: String, x: Float, y: Float, size: Float, col: Int) { txt.color = col; txt.textSize = size * d; cv.drawText(t, x, y, txt) }
    private fun glowLine(cv: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, w: Float, col: Int) {
        cv.drawLine(x1, y1, x2, y2, pen(soft(col), w + 10)); cv.drawLine(x1, y1, x2, y2, pen(col, w))
    }
    private fun limb(cv: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, w: Float) {
        cv.drawLine(x1, y1, x2, y2, pen(blue, w + 5)); cv.drawLine(x1, y1, x2, y2, pen(navy, w))
    }
    private fun tile(i: Int): RectF { val w = width * 0.2933f; val l = width * 0.04f + i * (w + width * 0.02f); return RectF(l, height * 0.845f, l + w, height * 0.928f) }
    private fun hist() = PointF(width - 44 * d, height * 0.134f)
    private fun gear() = PointF(width - 100 * d, height * 0.134f)

    private val bones = listOf(11 to 12, 11 to 13, 13 to 15, 12 to 14, 14 to 16, 11 to 23, 12 to 24, 23 to 24, 23 to 25, 25 to 27, 24 to 26, 26 to 28)
    private val joints = intArrayOf(11, 12, 13, 14, 15, 16, 23, 24, 25, 26, 27, 28)

    fun setSize(w: Int, h: Int) { iw = w; ih = h; invalidate() }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            Exercise.values().forEachIndexed { i, ex -> if (tile(i).contains(e.x, e.y)) onSelect(ex) }
            val h = hist(); if (hypot(e.x - h.x, e.y - h.y) < 32 * d) onHistory()
            val g = gear(); if (hypot(e.x - g.x, e.y - g.y) < 32 * d) onSettings()
        }
        return true
    }

    private fun icon(cv: Canvas, ex: Exercise, cx: Float, cy: Float, s: Float, col: Int) {
        val (hx, hy, l) = when (ex) {
            Exercise.PUSHUPS -> Triple(.38f, -.22f, floatArrayOf(.3f, -.1f, -.42f, .22f, .25f, -.05f, .25f, .28f, -.45f, .3f, .4f, .3f))
            Exercise.SITUPS -> Triple(-.36f, -.22f, floatArrayOf(-.1f, .25f, -.3f, -.05f, -.1f, .25f, .15f, -.02f, .15f, -.02f, .35f, .25f, -.45f, .3f, .4f, .3f))
            Exercise.SQUATS -> Triple(-.05f, -.32f, floatArrayOf(-.05f, -.2f, -.15f, .05f, -.15f, .05f, .2f, .1f, .2f, .1f, .1f, .35f, -.05f, -.15f, .25f, -.1f))
        }
        cv.drawCircle(cx + hx * s, cy + hy * s, .1f * s, fillP(col))
        for (k in l.indices step 4) cv.drawLine(cx + l[k] * s, cy + l[k + 1] * s, cx + l[k + 2] * s, cy + l[k + 3] * s, pen(col, 3.5f))
    }

    private fun drawShape(cv: Canvas) { cv.drawPath(path, bGlow); cv.drawPath(path, bFill); cv.drawPath(path, bEdge) }

    private fun oval(cv: Canvas, x: Float, y: Float, rx: Float, ry: Float, sheen: Boolean = false) {
        path.reset(); path.addOval(RectF(x - rx, y - ry, x + rx, y + ry), Path.Direction.CW)
        if (sheen) cv.drawPath(path, bSheen) else drawShape(cv)
    }

    // tapered limb with a muscle belly (w1 start, wm bulge near the start, w2 end) + a sheen stripe
    private fun muscle(cv: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, w1: Float, wm: Float, w2: Float, sheen: Boolean = true) {
        val dx = x2 - x1; val dy = y2 - y1; val len = hypot(dx, dy)
        if (len < 1f) return
        val nx = -dy / len; val ny = dx / len
        fun wAt(t: Float, k: Float) = (if (t < .45f) w1 + (wm - w1) * (t / .45f) else wm + (w2 - wm) * ((t - .45f) / .55f)) * k
        fun build(k: Float, t0: Float, t1: Float) {
            path.reset()
            for (i in 0..8) {
                val t = t0 + (t1 - t0) * i / 8f; val hw = wAt(t, k) / 2
                if (i == 0) path.moveTo(x1 + dx * t + nx * hw, y1 + dy * t + ny * hw) else path.lineTo(x1 + dx * t + nx * hw, y1 + dy * t + ny * hw)
            }
            for (i in 8 downTo 0) {
                val t = t0 + (t1 - t0) * i / 8f; val hw = wAt(t, k) / 2
                path.lineTo(x1 + dx * t - nx * hw, y1 + dy * t - ny * hw)
            }
            path.close()
        }
        build(1f, 0f, 1f); drawShape(cv)
        if (sheen) { build(.35f, .15f, .85f); cv.drawPath(path, bSheen) }
    }

    // muscular front view: broad shoulders, V-taper, pecs, abs, quads, calves
    private fun front(cv: Canvas, r: RectF) {
        val u = r.height() * .86f / 21f; val cx = r.centerX(); val t0 = r.top + r.height() * .07f
        fun X(v: Float) = cx + v * u
        fun Y(v: Float) = t0 + v * u
        val sides = floatArrayOf(-1f, 1f)
        for (sg in sides) {
            muscle(cv, X(sg * 1.0f), Y(10.8f), X(sg * 1.45f), Y(15.2f), 2.7f * u, 3.0f * u, 1.8f * u)
            muscle(cv, X(sg * 1.45f), Y(15.2f), X(sg * 1.5f), Y(20.0f), 1.8f * u, 2.2f * u, .9f * u)
            oval(cv, X(sg * 1.7f), Y(20.4f), .8f * u, .35f * u)
        }
        path.reset()
        path.moveTo(X(-.7f), Y(2.7f))
        path.cubicTo(X(-2f), Y(2.9f), X(-3.2f), Y(3f), X(-3.8f), Y(3.8f))
        path.cubicTo(X(-4f), Y(4.6f), X(-3.4f), Y(5.6f), X(-2.8f), Y(6.4f))
        path.cubicTo(X(-2.2f), Y(7.6f), X(-1.9f), Y(8.6f), X(-1.8f), Y(9.6f))
        path.lineTo(X(-2.1f), Y(10.8f)); path.lineTo(X(0f), Y(11.3f)); path.lineTo(X(2.1f), Y(10.8f)); path.lineTo(X(1.8f), Y(9.6f))
        path.cubicTo(X(1.9f), Y(8.6f), X(2.2f), Y(7.6f), X(2.8f), Y(6.4f))
        path.cubicTo(X(3.4f), Y(5.6f), X(4f), Y(4.6f), X(3.8f), Y(3.8f))
        path.cubicTo(X(3.2f), Y(3f), X(2f), Y(2.9f), X(.7f), Y(2.7f))
        path.close(); drawShape(cv)
        for (sg in sides) {
            muscle(cv, X(sg * 3.9f), Y(4.0f), X(sg * 4.7f), Y(7.2f), 2.2f * u, 2.3f * u, 1.5f * u)
            muscle(cv, X(sg * 4.7f), Y(7.2f), X(sg * 5.3f), Y(10.4f), 1.6f * u, 1.7f * u, .9f * u)
            oval(cv, X(sg * 5.4f), Y(10.9f), .5f * u, .6f * u)
            oval(cv, X(sg * 1.3f), Y(4.8f), 1.2f * u, .8f * u, true)       // pecs
            for (row in 0..2) oval(cv, X(sg * .5f), Y(6.5f + row * 1.1f), .45f * u, .45f * u, true)   // abs
        }
        muscle(cv, X(0f), Y(2.0f), X(0f), Y(3.1f), 1.1f * u, 1.2f * u, 1.5f * u, false)
        oval(cv, X(0f), Y(1.35f), .85f * u, 1.15f * u)
    }

    private fun trap(cv: Canvas, topW: Float, yTop: Float, botW: Float, yBot: Float, cx: Float) {
        path.reset()
        path.moveTo(cx - topW / 2, yTop); path.lineTo(cx + topW / 2, yTop)
        path.lineTo(cx + botW / 2, yBot); path.lineTo(cx - botW / 2, yBot); path.close()
        drawShape(cv)
    }

    private fun figure(cv: Canvas, ex: Exercise, r: RectF) {
        val u = r.height() / 10; val cx = r.centerX(); val cy = r.centerY(); val fl = cy + 1.6f * u
        when (ex) {
            Exercise.SQUATS -> front(cv, r)
            Exercise.PUSHUPS -> {   // plank seen from the front: straight arms down to the floor
                for (sg in floatArrayOf(-1f, 1f)) muscle(cv, cx + sg * .8f * u, cy + .5f * u, cx + sg * 1.0f * u, cy + 2.6f * u, .8f * u, .9f * u, .55f * u)
                trap(cv, 3.8f * u, cy - 1.7f * u, 2.2f * u, cy + .6f * u, cx)
                for (sg in floatArrayOf(-1f, 1f)) {
                    muscle(cv, cx + sg * 2.0f * u, cy - 1.6f * u, cx + sg * 2.1f * u, cy + 2.4f * u, 1.0f * u, 1.1f * u, .6f * u)
                    oval(cv, cx + sg * 2.1f * u, cy + 2.7f * u, .5f * u, .25f * u)
                    oval(cv, cx + sg * .9f * u, cy - .9f * u, .9f * u, .5f * u, true)
                }
                oval(cv, cx, cy - 2.7f * u, .6f * u, .7f * u)
                cv.drawLine(cx - 3.2f * u, cy + 2.95f * u, cx + 3.2f * u, cy + 2.95f * u, pen(0x55FFFFFF, 3))
            }
            Exercise.SITUPS -> {    // on your back, knees up, seen from your feet
                trap(cv, 3.4f * u, cy - 1.6f * u, 2.2f * u, cy + .2f * u, cx)
                oval(cv, cx, cy - 2.5f * u, .55f * u, .65f * u)
                for (sg in floatArrayOf(-1f, 1f)) {
                    muscle(cv, cx + sg * .7f * u, cy + .2f * u, cx + sg * .9f * u, cy + 1.5f * u, 1.0f * u, 1.1f * u, .8f * u)
                    muscle(cv, cx + sg * .9f * u, cy + 1.5f * u, cx + sg * .9f * u, cy + 2.7f * u, .7f * u, .75f * u, .4f * u)
                    oval(cv, cx + sg * .9f * u, cy + 2.9f * u, .4f * u, .22f * u)
                    muscle(cv, cx + sg * 1.6f * u, cy - 1.4f * u, cx + sg * .2f * u, cy - .6f * u, .6f * u, .6f * u, .45f * u)
                }
                cv.drawLine(cx - 3.2f * u, cy + 3.1f * u, cx + 3.2f * u, cy + 3.1f * u, pen(0x55FFFFFF, 3))
            }
        }
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val s = max(w / iw, h / ih); val dx = (w - iw * s) / 2; val dy = (h - ih * s) / 2
        fun X(i: Int) = (iw - rc.x[i]) * s + dx   // mirrored like the front-camera preview
        fun Y(i: Int) = rc.y[i] * s + dy

        if (rc.state == State.WAIT) cv.drawRect(0f, 0f, w, h, fillP(0xE0040810.toInt()))
        else if (rc.state == State.COUNTDOWN) cv.drawRect(0f, 0f, w, h, fillP(0x99040810.toInt()))

        if (rc.state == State.WAIT) {   // glass card with body guide
            rf.set(w * .145f, h * .243f, w * .855f, h * .655f)
            cv.drawRoundRect(rf, 32 * d, 32 * d, fillP(0x22103060))
            cv.drawRoundRect(rf, 32 * d, 32 * d, pen(soft(blue), 12))
            cv.drawRoundRect(rf, 32 * d, 32 * d, pen(blue, 2.5f))
            figure(cv, rc.exercise, rf)
        }

        for ((a, b) in bones) if (rc.vis[a] && rc.vis[b]) glowLine(cv, X(a), Y(a), X(b), Y(b), 3f, 0xFF5CB3FF.toInt())
        for (i in joints) if (rc.vis[i]) cv.drawCircle(X(i), Y(i), 5 * d, fillP(Color.WHITE))

        // range slider (orange): rises through a full rep
        val sx = w * .07f; val st = h * .3f; val sb = h * .7f
        cv.drawLine(sx, st, sx, sb, pen(0x33FFFFFF, 12))
        if (rc.effort > 0.03f) cv.drawLine(sx, sb, sx, sb - (sb - st) * rc.effort, pen(orange, 12))

        // progress ring: countdown, then rep depth; number = countdown, then reps
        val r = w * .14f; val cx = w * .21f; val cy = h * .134f
        cv.drawCircle(cx, cy, r, pen(0x331E90FF, 8))
        val sweep = when (rc.state) { State.COUNTDOWN -> (4 - rc.countdown) / 3f; State.COUNT -> rc.effort; else -> 0f } * 360f
        rf.set(cx - r, cy - r, cx + r, cy + r)
        if (sweep > 1f) { cv.drawArc(rf, -90f, sweep, false, pen(soft(blue), 16)); cv.drawArc(rf, -90f, sweep, false, pen(blue, 8)) }
        text(cv, "${if (rc.state == State.COUNTDOWN) rc.countdown else rc.reps}", cx, cy + 24 * d, 68f, Color.WHITE)
        text(cv, rc.exercise.label, cx, cy + r + 36 * d, 24f, Color.WHITE)

        // history button
        val hp = hist()
        cv.drawCircle(hp.x, hp.y, 24 * d, fillP(0x55101828)); cv.drawCircle(hp.x, hp.y, 24 * d, pen(0x66FFFFFF, 1.5f))
        cv.drawCircle(hp.x, hp.y, 10 * d, pen(Color.WHITE, 2f))
        cv.drawLine(hp.x, hp.y, hp.x, hp.y - 6 * d, pen(Color.WHITE, 2f)); cv.drawLine(hp.x, hp.y, hp.x + 4 * d, hp.y, pen(Color.WHITE, 2f))
        val gp = gear()   // settings button (three sliders)
        cv.drawCircle(gp.x, gp.y, 24 * d, fillP(0x55101828)); cv.drawCircle(gp.x, gp.y, 24 * d, pen(0x66FFFFFF, 1.5f))
        for ((k, off) in listOf(-7 to -3, 0 to 4, 7 to -1)) {
            cv.drawLine(gp.x - 10 * d, gp.y + k * d, gp.x + 10 * d, gp.y + k * d, pen(Color.WHITE, 2f))
            cv.drawCircle(gp.x + off * d, gp.y + k * d, 3 * d, fillP(ice))
        }

        val m = rc.message
        if (m.isNotEmpty()) {
            val mid = m.indexOf(' ', m.length / 2)
            val ls = if (mid > 0) listOf(m.substring(0, mid), m.substring(mid + 1)) else listOf(m)
            ls.forEachIndexed { i, t -> text(cv, t, w / 2, h * .70f + i * 30 * d, 22f, if (i == 0) Color.WHITE else muted) }
        }
        if (rc.state != State.COUNT)
            rc.exercise.tips.forEachIndexed { i, t -> text(cv, t, w / 2, h * .765f + i * 22 * d, 13f, 0xFF9DB4E0.toInt()) }

        Exercise.values().forEachIndexed { i, ex ->
            val t = tile(i); val sel = ex == rc.exercise; val col = if (sel) ice else gray
            cv.drawRoundRect(t, 18 * d, 18 * d, fillP(if (sel) 0x66123A7A else 0x88101828.toInt()))
            if (sel) cv.drawRoundRect(t, 18 * d, 18 * d, pen(soft(blue), 10))
            cv.drawRoundRect(t, 18 * d, 18 * d, pen(if (sel) blue else 0x44FFFFFF, if (sel) 2.5f else 1f))
            icon(cv, ex, t.centerX(), t.top + t.height() * .38f, t.height() * .5f, col)
            text(cv, ex.label.uppercase(), t.centerX(), t.bottom - 12 * d, 12f, col)
        }
    }
}
