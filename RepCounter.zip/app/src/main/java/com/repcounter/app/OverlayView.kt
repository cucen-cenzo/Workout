package com.repcounter.app

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max

class OverlayView(c: Context, private val rc: RepCounter) : View(c) {
    var onSelect: (Exercise) -> Unit = {}
    var onHistory: () -> Unit = {}
    private var iw = 1; private var ih = 1
    private val d = resources.displayMetrics.density
    private val blue = 0xFF2E8BFF.toInt(); private val orange = 0xFFF5A623.toInt(); private val navy = 0xFF0A1B3D.toInt()
    private val muted = 0xFF7A8BB5.toInt(); private val ice = 0xFF7CC4FF.toInt(); private val gray = 0xFFB0B8C8.toInt()
    private val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }
    private val rf = RectF()

    private fun pen(col: Int, sw: Number = 0, st: Paint.Style = Paint.Style.STROKE): Paint { sp.color = col; sp.strokeWidth = sw.toFloat() * d; sp.style = st; return sp }
    private fun fillP(col: Int) = pen(col, 0f, Paint.Style.FILL)
    private fun soft(col: Int) = (col and 0xFFFFFF) or 0x33000000
    private fun text(cv: Canvas, t: String, x: Float, y: Float, size: Float, col: Int) { txt.color = col; txt.textSize = size * d; cv.drawText(t, x, y, txt) }
    private fun glowLine(cv: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, w: Float, col: Int) {
        cv.drawLine(x1, y1, x2, y2, pen(soft(col), w + 10)); cv.drawLine(x1, y1, x2, y2, pen(col, w))
    }
    private fun limb(cv: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, w: Float) {
        cv.drawLine(x1, y1, x2, y2, pen(blue, w + 5)); cv.drawLine(x1, y1, x2, y2, pen(navy, w))
    }
    private fun tile(i: Int): RectF { val w = width * 0.2933f; val l = width * 0.04f + i * (w + width * 0.02f); return RectF(l, height * 0.845f, l + w, height * 0.928f) }
    private fun hist() = PointF(width - 44 * d, height * 0.134f)

    private val bones = listOf(11 to 12, 11 to 13, 13 to 15, 12 to 14, 14 to 16, 11 to 23, 12 to 24, 23 to 24, 23 to 25, 25 to 27, 24 to 26, 26 to 28)
    private val joints = intArrayOf(11, 12, 13, 14, 15, 16, 23, 24, 25, 26, 27, 28)

    fun setSize(w: Int, h: Int) { iw = w; ih = h; invalidate() }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            Exercise.values().forEachIndexed { i, ex -> if (tile(i).contains(e.x, e.y)) onSelect(ex) }
            val h = hist(); if (hypot(e.x - h.x, e.y - h.y) < 32 * d) onHistory()
        }
        return true
    }

    private fun icon(cv: Canvas, ex: Exercise, cx: Float, cy: Float, s: Float, col: Int) {
        val (hx, hy, l) = when (ex) {
            Exercise.PUSHUPS -> Triple(.38f, -.22f, floatArrayOf(.3f, -.1f, -.42f, .22f, .25f, -.05f, .25f, .28f, -.45f, .3f, .4f, .3f))
            Exercise.SITUPS -> Triple(-.36f, -.22f, floatArrayOf(-.1f, .25f, -.3f, -.05f, -.1f, .25f, .15f, -.02f, .15f, -.02f, .35f, .25f, -.45f, .3f, .4f, .3f))
            Exercise.SQUATS -> Triple(-.05f, -.32f, floatArrayOf(-.05f, -.2f, -.15f, .05f, -.15f, .05f, .2f, .1f, .2f, .1f, .1f, .35f, -.05f, -.15f, .25f, -.1f))
        }
        cv.drawCircle(cx + hx * s, cy + hy * s, .1f * s, fillP(col))
        for (k in l.indices step 4) cv.drawLine(cx + l[k] * s, cy + l[k + 1] * s, cx + l[k + 2] * s, cy + l[k + 3] * s, pen(col, 3.5f))
    }

    private fun figure(cv: Canvas, ex: Exercise, r: RectF) {
        val u = r.height() / 10; val cx = r.centerX(); val cy = r.centerY(); val fl = cy + 1.6f * u
        fun head(x: Float, y: Float) { cv.drawCircle(x, y, .55f * u, fillP(blue)); cv.drawCircle(x, y, .55f * u - 2.5f * d, fillP(navy)) }
        when (ex) {
            Exercise.SQUATS -> {
                val top = r.top + r.height() * .08f; val uu = r.height() * .84f / 10
                for (sg in intArrayOf(-1, 1)) {
                    limb(cv, cx + sg * .9f * uu, top + 2.5f * uu, cx + sg * 2.1f * uu, top + 5.6f * uu, 14f)
                    limb(cv, cx + sg * .3f * uu, top + 5.2f * uu, cx + sg * .8f * uu, top + 9.4f * uu, 24f)
                }
                limb(cv, cx, top + 2.3f * uu, cx, top + 5.2f * uu, 50f)
                head(cx, top + .9f * uu)
            }
            Exercise.PUSHUPS -> {   // side view, plank, arms straight
                cv.drawLine(cx - 3.8f * u, fl, cx + 3.8f * u, fl, pen(0x55FFFFFF, 3))
                limb(cv, cx - .9f * u, cy + .55f * u, cx - 3.2f * u, fl - .3f * u, 22f)
                limb(cv, cx + 2f * u, cy - .4f * u, cx - .9f * u, cy + .55f * u, 38f)
                limb(cv, cx + 2f * u, cy - .4f * u, cx + 2f * u, fl - .1f * u, 14f)
                head(cx + 2.95f * u, cy - .7f * u)
            }
            Exercise.SITUPS -> {    // side view, on your back, knees bent
                cv.drawLine(cx - 3.8f * u, fl, cx + 3.8f * u, fl, pen(0x55FFFFFF, 3))
                limb(cv, cx - .1f * u, fl - .55f * u, cx + 1.1f * u, fl - 2.3f * u, 24f)
                limb(cv, cx + 1.1f * u, fl - 2.3f * u, cx + 2.3f * u, fl - .3f * u, 20f)
                limb(cv, cx - 2.2f * u, fl - .55f * u, cx - .1f * u, fl - .55f * u, 36f)
                head(cx - 3.1f * u, fl - .6f * u)
            }
        }
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val s = max(w / iw, h / ih); val dx = (w - iw * s) / 2; val dy = (h - ih * s) / 2
        fun X(i: Int) = (iw - rc.x[i]) * s + dx   // mirrored like the front-camera preview
        fun Y(i: Int) = rc.y[i] * s + dy

        if (rc.state == State.WAIT) cv.drawRect(0f, 0f, w, h, fillP(0xE0040810.toInt()))
        else if (rc.state == State.COUNTDOWN) cv.drawRect(0f, 0f, w, h, fillP(0x99040810.toInt()))

        if (rc.state == State.WAIT) {   // glass card with body guide
            rf.set(w * .145f, h * .243f, w * .855f, h * .655f)
            cv.drawRoundRect(rf, 32 * d, 32 * d, fillP(0x22103060))
            cv.drawRoundRect(rf, 32 * d, 32 * d, pen(soft(blue), 12))
            cv.drawRoundRect(rf, 32 * d, 32 * d, pen(blue, 2.5f))
            figure(cv, rc.exercise, rf)
        }

        for ((a, b) in bones) if (rc.vis[a] && rc.vis[b]) glowLine(cv, X(a), Y(a), X(b), Y(b), 3f, 0xFF5CB3FF.toInt())
        for (i in joints) if (rc.vis[i]) cv.drawCircle(X(i), Y(i), 5 * d, fillP(Color.WHITE))

        // range slider (orange): rises through a full rep
        val sx = w * .07f; val st = h * .3f; val sb = h * .7f
        cv.drawLine(sx, st, sx, sb, pen(0x33FFFFFF, 12))
        if (rc.effort > 0.03f) cv.drawLine(sx, sb, sx, sb - (sb - st) * rc.effort, pen(orange, 12))

        // progress ring: countdown, then rep depth; number = countdown, then reps
        val r = w * .14f; val cx = w * .21f; val cy = h * .134f
        cv.drawCircle(cx, cy, r, pen(0x331E90FF, 8))
        val sweep = when (rc.state) { State.COUNTDOWN -> (4 - rc.countdown) / 3f; State.COUNT -> rc.effort; else -> 0f } * 360f
        rf.set(cx - r, cy - r, cx + r, cy + r)
        if (sweep > 1f) { cv.drawArc(rf, -90f, sweep, false, pen(soft(blue), 16)); cv.drawArc(rf, -90f, sweep, false, pen(blue, 8)) }
        text(cv, "${if (rc.state == State.COUNTDOWN) rc.countdown else rc.reps}", cx, cy + 24 * d, 68f, Color.WHITE)
        text(cv, rc.exercise.label, cx, cy + r + 36 * d, 24f, Color.WHITE)

        // history button
        val hp = hist()
        cv.drawCircle(hp.x, hp.y, 24 * d, fillP(0x55101828)); cv.drawCircle(hp.x, hp.y, 24 * d, pen(0x66FFFFFF, 1.5f))
        cv.drawCircle(hp.x, hp.y, 10 * d, pen(Color.WHITE, 2f))
        cv.drawLine(hp.x, hp.y, hp.x, hp.y - 6 * d, pen(Color.WHITE, 2f)); cv.drawLine(hp.x, hp.y, hp.x + 4 * d, hp.y, pen(Color.WHITE, 2f))

        val m = rc.message
        if (m.isNotEmpty()) {
            val mid = m.indexOf(' ', m.length / 2)
            val ls = if (mid > 0) listOf(m.substring(0, mid), m.substring(mid + 1)) else listOf(m)
            ls.forEachIndexed { i, t -> text(cv, t, w / 2, h * .70f + i * 30 * d, 22f, if (i == 0) Color.WHITE else muted) }
        }
        if (rc.state != State.COUNT)
            rc.exercise.tips.forEachIndexed { i, t -> text(cv, t, w / 2, h * .765f + i * 22 * d, 13f, 0xFF9DB4E0.toInt()) }

        Exercise.values().forEachIndexed { i, ex ->
            val t = tile(i); val sel = ex == rc.exercise; val col = if (sel) ice else gray
            cv.drawRoundRect(t, 18 * d, 18 * d, fillP(if (sel) 0x66123A7A else 0x88101828.toInt()))
            if (sel) cv.drawRoundRect(t, 18 * d, 18 * d, pen(soft(blue), 10))
            cv.drawRoundRect(t, 18 * d, 18 * d, pen(if (sel) blue else 0x44FFFFFF, if (sel) 2.5f else 1f))
            icon(cv, ex, t.centerX(), t.top + t.height() * .38f, t.height() * .5f, col)
            text(cv, ex.label.uppercase(), t.centerX(), t.bottom - 12 * d, 12f, col)
        }
    }
}
