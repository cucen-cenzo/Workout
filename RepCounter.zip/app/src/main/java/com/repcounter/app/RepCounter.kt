package com.repcounter.app

import com.google.mlkit.vision.pose.Pose
import kotlin.math.abs
import kotlin.math.atan2

// joints = left-side landmark indices (a, b, c); right side is +1. Angle measured at b.
enum class Exercise(val label: String, val joints: Triple<Int, Int, Int>, val open: Double, val closed: Double) {
    PUSHUPS("Push-ups", Triple(11, 13, 15), 165.0, 90.0),   // shoulder-elbow-wrist
    SITUPS("Sit-ups", Triple(11, 23, 25), 150.0, 70.0),     // shoulder-hip-knee
    SQUATS("Squats", Triple(23, 25, 27), 165.0, 95.0)       // hip-knee-ankle
}

class RepCounter {
    var exercise = Exercise.PUSHUPS
        set(v) { field = v; reset() }
    var reps = 0; private set
    var progress = 0f; private set   // 0 = start position, 1 = full range
    private var down = false

    fun reset() { reps = 0; progress = 0f; down = false }

    fun update(pose: Pose): Boolean {
        val (a, b, c) = exercise.joints
        var best = -1; var conf = 0.5f
        for (side in 0..1) {
            val m = listOf(a, b, c).minOf { pose.getPoseLandmark(it + side)?.inFrameLikelihood ?: 0f }
            if (m > conf) { conf = m; best = side }
        }
        if (best < 0) return false
        fun p(i: Int) = pose.getPoseLandmark(i + best)!!.position
        val pa = p(a); val pb = p(b); val pc = p(c)
        var ang = abs(Math.toDegrees((atan2(pc.y - pb.y, pc.x - pb.x) - atan2(pa.y - pb.y, pa.x - pb.x)).toDouble()))
        if (ang > 180) ang = 360 - ang
        val raw = ((exercise.open - ang) / (exercise.open - exercise.closed)).coerceIn(0.0, 1.0).toFloat()
        progress = progress * 0.6f + raw * 0.4f
        if (progress > 0.8f) down = true
        else if (progress < 0.2f && down) { down = false; reps++ }
        return true
    }
}
