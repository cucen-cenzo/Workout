package com.repcounter.app

import com.google.mlkit.vision.pose.Pose
import kotlin.math.*

// joints = left-side landmark ids (a, b, c), angle at b; right side = +1.
// extra = one more joint that must be visible (0 = none). range = degrees of movement for a full rep.
enum class Exercise(val label: String, val joints: Triple<Int, Int, Int>, val extra: Int, val range: Float, val tips: List<String>) {
    PUSHUPS("Push-ups", Triple(11, 13, 15), 0, 60f, listOf(
        "Place the phone 2-3 m away, front or side",
        "Arms straight, hands under shoulders",
        "Hold still for the 3-2-1, then start")),
    SITUPS("Sit-ups", Triple(11, 23, 25), 0, 50f, listOf(
        "Place the phone 2-3 m away, side-on to you",
        "Lie on your back, feet flat, knees bent",
        "Hold still for the 3-2-1, then sit up")),
    SQUATS("Squats", Triple(23, 25, 27), 0, 65f, listOf(
        "Place the phone 2-3 m away, facing you",
        "Stand tall, feet shoulder-width apart",
        "Hold still for the 3-2-1, then squat"))
}
enum class State { WAIT, COUNTDOWN, COUNT }

const val MSG = "Keep your entire body visible on screen."
private const val SEEN = 0.35f
private const val HOLD = 600L
private const val LOST = 2000L
private const val DOWN_AT = 0.8f
private const val UP_AT = 0.25f
private const val MIN_REP_MS = 700L

class RepCounter {
    var exercise = Exercise.PUSHUPS
        set(v) { field = v; reset() }
    var reps = 0; private set
    var effort = 0f; private set
    var state = State.WAIT; private set
    var countdown = 3; private set
    var message = MSG; private set
    var onRep: ((Exercise) -> Unit)? = null
    val x = FloatArray(33); val y = FloatArray(33); val vis = BooleanArray(33)

    private val seenAt = LongArray(33)
    private var side = 0
    private var readySince = 0L; private var lostSince = 0L; private var badSince = 0L; private var cdStart = 0L; private var leftT = 0L
    private var down = false; private var frozen = false; private var sigSm = 0f
    private var baseSig = 0f; private var baseSY = 0f; private var baseArm = 1f
    private val samples = ArrayList<FloatArray>()
    val depth = floatArrayOf(1f, 1f, 1f)   // rep-depth scale per exercise (from Settings)
    private var topH = 0f; private var hSm = 0f; private var lastT = 0L

    fun reset() { reps = 0; toWait(MSG) }

    private fun toWait(msg: String) {
        state = State.WAIT; effort = 0f; down = false; frozen = false; leftT = 0; readySince = 0; badSince = 0; message = msg
    }

    @Suppress("UNUSED_PARAMETER")
    fun update(pose: Pose, w: Int, h: Int, now: Long) {
        val dtS = if (lastT == 0L) 0f else ((now - lastT) / 1000f).coerceAtMost(0.5f)
        lastT = now
        for (i in 11..28) {
            val l = pose.getPoseLandmark(i)
            if (l != null && l.inFrameLikelihood > SEEN) {
                val fresh = now - seenAt[i] > HOLD
                x[i] = if (fresh) l.position.x else x[i] + (l.position.x - x[i]) * 0.5f
                y[i] = if (fresh) l.position.y else y[i] + (l.position.y - y[i]) * 0.5f
                seenAt[i] = now
            }
            vis[i] = now - seenAt[i] <= HOLD
        }

        val (a, b, c) = exercise.joints
        fun ok(sd: Int) = vis[a + sd] && vis[b + sd] && vis[c + sd] && (exercise.extra == 0 || vis[exercise.extra + sd])
        val sd = if (ok(side)) side else if (ok(1 - side)) 1 - side else -1
        if (sd < 0) {
            if (lostSince == 0L) lostSince = now
            readySince = 0
            when (state) {
                State.COUNT -> if (now - lostSince > LOST) toWait(MSG) else if (now - lostSince > 700) message = MSG
                State.COUNTDOWN -> if (now - lostSince > 1000) toWait(MSG)
                else -> message = MSG
            }
            return
        }
        lostSince = 0; side = sd
        fun px(i: Int) = x[i + sd]
        fun py(i: Int) = y[i + sd]

        // signals
        val sit = exercise == Exercise.SITUPS
        val push = exercise == Exercise.PUSHUPS
        // torso tilt: 0 = lying flat, 90 = upright (needs shoulder + hip)
        val tilt = if (vis[11 + sd] && vis[23 + sd])
            Math.toDegrees(atan2(abs(py(11) - py(23)), abs(px(11) - px(23))).toDouble()).toFloat() else -1f
        var ang = abs(Math.toDegrees((atan2(py(c) - py(b), px(c) - px(b)) - atan2(py(a) - py(b), px(a) - px(b))).toDouble())).toFloat()
        if (ang > 180f) ang = 360f - ang
        val sig = if (sit) tilt else ang      // sit-ups: how far the torso has risen; others: joint angle
        sigSm = if (state == State.WAIT) sig else sigSm * 0.6f + sig * 0.4f
        val sy = if (push) py(11) else 0f
        val arm = if (push) hypot(px(11) - px(13), py(11) - py(13)) + hypot(px(13) - px(15), py(13) - py(15)) else 1f
        // push-ups: vertical distance shoulder->wrist. Same idea from the front or the side, and
        // independent of where you stand, so standing -> plank can't confuse it.
        var hs = 0f; var hn = 0
        for (s2 in 0..1) if (vis[11 + s2] && vis[15 + s2]) { hs += y[15 + s2] - y[11 + s2]; hn++ }
        val hh = if (push && hn > 0) hs / hn else 0f
        hSm = if (state == State.WAIT) hh else hSm * 0.6f + hh * 0.4f

        // is the person actually in the start position?
        fun startHint(): String? = when (exercise) {
            Exercise.PUSHUPS -> if (hh < 0.2f * arm) "Put your hands on the floor under your shoulders" else null
            Exercise.SITUPS -> if (tilt > 35f) "Lie down on your back" else null
            Exercise.SQUATS -> if (tilt in 0f..55f) "Stand up straight" else null
        }
        // person stood up / left the exercise while counting -> pause, never count
        fun brokeForm(): Boolean = when (exercise) {
            Exercise.PUSHUPS -> topH > 0f && hSm < (if (frozen) 0.25f else 0.12f) * topH   // wrists up near/above shoulders
            Exercise.SITUPS -> tilt > 55f && (py(25) - py(23)) > 0.6f * hypot(px(25) - px(23), py(25) - py(23))
            else -> false
        }

        when (state) {
            State.WAIT -> {
                val hint = startHint()
                if (hint != null) { readySince = 0; message = hint }
                else {
                    if (readySince == 0L) readySince = now
                    message = "Good, hold that position"
                    if (now - readySince > 600) { state = State.COUNTDOWN; cdStart = now; badSince = 0; samples.clear() }
                }
            }
            State.COUNTDOWN -> {
                val hint = startHint()
                if (hint != null) {
                    if (badSince == 0L) badSince = now
                    if (now - badSince > 1000) { toWait(hint); return }
                } else badSince = 0
                message = "Hold this position"
                val t = now - cdStart
                countdown = (3 - (t / 1000).toInt()).coerceAtLeast(1)
                if (t > 1800) samples.add(floatArrayOf(sigSm, hSm, arm))
                if (t >= 3000) {
                    if (samples.isEmpty()) samples.add(floatArrayOf(sigSm, hSm, arm))
                    fun med(k: Int) = samples.map { it[k] }.sorted()[samples.size / 2]
                    baseSig = med(0); topH = med(1); baseArm = max(med(2), 1f)
                    state = State.COUNT; message = ""; down = false; frozen = false; leftT = 0; effort = 0f
                }
            }
            State.COUNT -> {
                if (brokeForm()) {
                    frozen = true; effort = 0f; down = false; leftT = 0
                    message = if (push) "Get back into push-up position" else "Lie back down to continue"
                    return
                }
                frozen = false; message = ""
                val scale = depth[exercise.ordinal]
                val f: Float
                if (push) {
                    topH = max(topH * (1f - 0.03f * dtS), hSm)   // "arms straight" height; adapts slowly
                    f = (topH - hSm) / (0.55f * max(topH, 20f) * scale)
                } else {
                    val diff = if (sit) sigSm - baseSig else abs(sigSm - baseSig)   // sit-ups only count going UP from lying
                    f = diff / (exercise.range * scale)
                }
                effort = effort * 0.4f + f.coerceIn(0f, 1f) * 0.6f
                if (!down) {
                    if (effort < 0.2f) baseSig += (sigSm - baseSig) * 0.02f
                    if (effort > 0.2f && leftT == 0L) leftT = now
                    if (effort < 0.1f) leftT = 0
                    if (effort > DOWN_AT) down = true
                } else if (effort < UP_AT) {
                    down = false
                    if (leftT != 0L && now - leftT >= MIN_REP_MS) { reps++; onRep?.invoke(exercise) }
                    leftT = 0
                }
            }
        }
    }
}
