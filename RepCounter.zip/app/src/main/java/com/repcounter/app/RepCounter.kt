package com.repcounter.app

import com.google.mlkit.vision.pose.Pose
import kotlin.math.*

// joints = left-side landmark ids (a, b, c), angle measured at b; right side = +1.
// Only these 3 joints must be visible (not the whole body), so feet/hands out of frame is fine.
enum class Exercise(val label: String, val joints: Triple<Int, Int, Int>, val range: Float) {
    PUSHUPS("Push-ups", Triple(11, 13, 15), 60f),   // shoulder-elbow-wrist
    SITUPS("Sit-ups", Triple(11, 23, 25), 55f),     // shoulder-hip-knee
    SQUATS("Squats", Triple(23, 25, 27), 65f)       // hip-knee-ankle
}
enum class State { WAIT, COUNTDOWN, COUNT }

const val MSG = "Keep your entire body visible on screen."
private const val SEEN = 0.35f     // min ML Kit confidence to accept a joint
private const val HOLD = 600L      // a joint stays "visible" this long after last seen (kills flicker)
private const val LOST = 2000L     // body gone this long while counting -> back to start screen
private const val DOWN_AT = 0.8f   // effort needed to count as full depth
private const val UP_AT = 0.25f    // effort to drop below to finish the rep
private const val MIN_REP_MS = 700L

class RepCounter {
    var exercise = Exercise.PUSHUPS
        set(v) { field = v; reset() }
    var reps = 0; private set
    var effort = 0f; private set          // 0 = start position, 1 = full rep depth
    var state = State.WAIT; private set
    var countdown = 3; private set
    var message = MSG; private set
    var onRep: ((Exercise) -> Unit)? = null
    val x = FloatArray(33); val y = FloatArray(33); val vis = BooleanArray(33)

    private val seenAt = LongArray(33)
    private var side = 0
    private var readySince = 0L; private var lostSince = 0L; private var cdStart = 0L; private var leftT = 0L
    private var down = false; private var angSm = 0f
    private var baseAng = 0f; private var baseSY = 0f; private var baseArm = 1f
    private val samples = ArrayList<FloatArray>()

    fun reset() { reps = 0; toWait(MSG) }

    private fun toWait(msg: String) { state = State.WAIT; effort = 0f; down = false; leftT = 0; readySince = 0; message = msg }

    @Suppress("UNUSED_PARAMETER")
    fun update(pose: Pose, w: Int, h: Int, now: Long) {
        // 1) smoothed joints; a joint counts as visible for HOLD ms after it was last seen
        for (i in 11..28) {
            val l = pose.getPoseLandmark(i)
            if (l != null && l.inFrameLikelihood > SEEN) {
                val fresh = now - seenAt[i] > HOLD
                x[i] = if (fresh) l.position.x else x[i] + (l.position.x - x[i]) * 0.5f
                y[i] = if (fresh) l.position.y else y[i] + (l.position.y - y[i]) * 0.5f
                seenAt[i] = now
            }
            vis[i] = now - seenAt[i] <= HOLD
        }

        // 2) only the 3 joints of this exercise on one side are required (sticky side)
        val (a, b, c) = exercise.joints
        fun ok(sd: Int) = vis[a + sd] && vis[b + sd] && vis[c + sd]
        val sd = if (ok(side)) side else if (ok(1 - side)) 1 - side else -1
        if (sd < 0) {
            if (lostSince == 0L) lostSince = now
            readySince = 0
            when (state) {
                State.COUNT -> if (now - lostSince > LOST) toWait(MSG) else if (now - lostSince > 700) message = MSG
                State.COUNTDOWN -> if (now - lostSince > 1000) toWait(MSG)   // short dropouts ride through
                else -> message = MSG
            }
            return
        }
        lostSince = 0; side = sd
        fun px(i: Int) = x[i + sd]
        fun py(i: Int) = y[i + sd]

        // 3) signals
        var ang = abs(Math.toDegrees((atan2(py(c) - py(b), px(c) - px(b)) - atan2(py(a) - py(b), px(a) - px(b))).toDouble())).toFloat()
        if (ang > 180f) ang = 360f - ang
        angSm = if (state == State.WAIT) ang else angSm * 0.6f + ang * 0.4f
        val push = exercise == Exercise.PUSHUPS
        val sy = if (push) py(11) else 0f
        val arm = if (push) hypot(px(11) - px(13), py(11) - py(13)) + hypot(px(13) - px(15), py(13) - py(15)) else 1f

        // 4) state machine
        when (state) {
            State.WAIT -> {
                if (readySince == 0L) readySince = now
                if (now - readySince > 600) { state = State.COUNTDOWN; cdStart = now; samples.clear() }
            }
            State.COUNTDOWN -> {
                message = "Get in your start position"
                val t = now - cdStart
                countdown = (3 - (t / 1000).toInt()).coerceAtLeast(1)
                if (t > 1800) samples.add(floatArrayOf(angSm, sy, arm))
                if (t >= 3000) {   // never fails: calibrate from the last ~1s and go
                    if (samples.isEmpty()) samples.add(floatArrayOf(angSm, sy, arm))
                    fun med(k: Int) = samples.map { it[k] }.sorted()[samples.size / 2]
                    baseAng = med(0); baseSY = med(1); baseArm = max(med(2), 1f)
                    state = State.COUNT; message = ""; down = false; leftT = 0; effort = 0f
                }
            }
            State.COUNT -> {
                message = ""
                var f = abs(angSm - baseAng) / exercise.range   // direction-agnostic: moving away from start = up
                if (push) f = max(f, (sy - baseSY) / (0.4f * baseArm))
                effort = effort * 0.4f + f.coerceIn(0f, 1f) * 0.6f
                if (!down) {
                    if (effort < 0.2f) { baseAng += (angSm - baseAng) * 0.02f; baseSY += (sy - baseSY) * 0.02f }   // follow slow drift
                    if (effort > 0.2f && leftT == 0L) leftT = now
                    if (effort < 0.1f) leftT = 0
                    if (effort > DOWN_AT) down = true
                } else if (effort < UP_AT) {
                    down = false
                    if (leftT != 0L && now - leftT >= MIN_REP_MS) { reps++; onRep?.invoke(exercise) }
                    leftT = 0
                }
            }
        }
    }
}
