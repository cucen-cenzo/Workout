package com.repcounter.app

import com.google.mlkit.vision.pose.Pose
import kotlin.math.*

// joints = left-side landmark ids (a, b, c), angle measured at b; right side = +1
enum class Exercise(val label: String, val joints: Triple<Int, Int, Int>, val range: Float) {
    PUSHUPS("Push-ups", Triple(11, 13, 15), 70f),
    SITUPS("Sit-ups", Triple(11, 23, 25), 60f),
    SQUATS("Squats", Triple(23, 25, 27), 70f)
}
enum class State { WAIT, COUNTDOWN, COUNT }

const val MSG = "Keep your entire body visible on screen."

class RepCounter {
    var exercise = Exercise.PUSHUPS
        set(v) { field = v; reset() }
    var reps = 0; private set
    var effort = 0f; private set          // 0 = start position, 1 = full rep depth
    var state = State.WAIT; private set
    var countdown = 3; private set
    var message = MSG; private set
    var onRep: ((Exercise) -> Unit)? = null
    val x = FloatArray(33); val y = FloatArray(33); val vis = BooleanArray(33)

    private var side = 0
    private var seenSince = 0L; private var lostSince = 0L; private var cdStart = 0L; private var leftT = 0L
    private var down = false
    private var baseAng = 0f; private var baseSY = 0f; private var baseArm = 1f
    private val samples = ArrayList<FloatArray>()

    fun reset() { reps = 0; effort = 0f; down = false; leftT = 0; seenSince = 0; state = State.WAIT; message = MSG }

    fun update(pose: Pose, w: Int, h: Int, now: Long) {
        for (i in 11..28) {
            val l = pose.getPoseLandmark(i)
            val ok = l != null && l.inFrameLikelihood > 0.5f && l.position.x in 0f..w.toFloat() && l.position.y in 0f..h.toFloat()
            vis[i] = ok
            if (ok) {
                val nx = l!!.position.x; val ny = l.position.y
                if (x[i] == 0f) { x[i] = nx; y[i] = ny } else { x[i] += (nx - x[i]) * 0.5f; y[i] += (ny - y[i]) * 0.5f }
            }
        }
        val chain = intArrayOf(11, 13, 15, 23, 25, 27)
        val s = (0..1).firstOrNull { sd -> chain.all { vis[it + sd] } }
        if (s == null) {   // full body not in frame: never count
            seenSince = 0
            if (lostSince == 0L) lostSince = now
            if (state != State.COUNT || now - lostSince > 1500) { state = State.WAIT; effort = 0f; down = false; leftT = 0; message = MSG }
            return
        }
        lostSince = 0; side = s
        fun px(i: Int) = x[i + side]
        fun py(i: Int) = y[i + side]
        val (a, b, c) = exercise.joints
        var ang = abs(Math.toDegrees((atan2(py(c) - py(b), px(c) - px(b)) - atan2(py(a) - py(b), px(a) - px(b))).toDouble())).toFloat()
        if (ang > 180f) ang = 360f - ang
        val sy = py(11)
        val arm = hypot(px(11) - px(13), py(11) - py(13)) + hypot(px(13) - px(15), py(13) - py(15))
        val tx = abs(px(11) - px(23)); val ty = abs(py(11) - py(23))
        val startOk = when (exercise) { Exercise.SITUPS -> tx > ty; Exercise.SQUATS -> ty > tx; else -> true }

        when (state) {
            State.WAIT -> {
                if (seenSince == 0L) seenSince = now
                if (now - seenSince > 800) { state = State.COUNTDOWN; cdStart = now; samples.clear() }
            }
            State.COUNTDOWN -> {
                message = "Hold your start position"
                val t = now - cdStart
                countdown = 3 - (t / 1000).toInt()
                if (t > 2000) samples.add(floatArrayOf(ang, sy, arm))
                if (t >= 3000) {
                    val steady = samples.size > 3 && samples.maxOf { it[0] } - samples.minOf { it[0] } < 12f
                    if (steady && startOk) {
                        baseAng = samples.map { it[0] }.average().toFloat()
                        baseSY = samples.map { it[1] }.average().toFloat()
                        baseArm = samples.map { it[2] }.average().toFloat()
                        state = State.COUNT; message = ""; down = false; leftT = 0
                    } else { state = State.WAIT; seenSince = 0; message = "Start position not detected. Hold still and try again." }
                }
            }
            State.COUNT -> {
                var f = abs(ang - baseAng) / exercise.range   // direction-agnostic: moving away from start = up
                if (exercise == Exercise.PUSHUPS) f = max(f, (sy - baseSY) / (0.45f * baseArm))
                effort = effort * 0.5f + f.coerceIn(0f, 1f) * 0.5f
                if (!down) {
                    if (effort > 0.2f && leftT == 0L) leftT = now
                    if (effort < 0.1f) leftT = 0
                    if (effort > 0.85f) down = true
                } else if (effort < 0.15f) {
                    down = false
                    if (leftT != 0L && now - leftT >= 800) { reps++; onRep?.invoke(exercise) }   // full depth + full return + not a jitter
                    leftT = 0
                }
            }
        }
    }
}
