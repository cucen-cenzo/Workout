package com.repcounter.app

import com.google.mlkit.vision.pose.Pose
import kotlin.math.*

// joints = left-side landmark ids (a, b, c), angle at b; right side = +1.
// range = how far a full rep moves (degrees for push-ups/squats, torso-rise ratio for sit-ups).
enum class Exercise(val label: String, val joints: Triple<Int, Int, Int>, val range: Float, val tips: List<String>) {
    PUSHUPS("Push-ups", Triple(11, 13, 15), 60f, listOf(
        "Place the phone 2-3 m away, facing you",
        "Arms straight, hands under shoulders",
        "Hold still for 3-2-1; counts only in plank")),
    SITUPS("Sit-ups", Triple(11, 23, 25), 0.7f, listOf(
        "Place the phone 2-3 m away, facing you",
        "Lie on your back, feet flat, knees bent",
        "Hold still for the 3-2-1, then sit up")),
    SQUATS("Squats", Triple(23, 25, 27), 65f, listOf(
        "Place the phone 2-3 m away, facing you",
        "Stand tall, feet shoulder-width apart",
        "Hold still for the 3-2-1, then squat"))
}
enum class State { WAIT, COUNTDOWN, COUNT }

const val MSG = "Keep your entire body visible on screen."
private const val SEEN = 0.35f
private const val HOLD = 600L
private const val LOST = 2000L
private const val DOWN_AT = 0.8f
private const val UP_AT = 0.25f
private const val MIN_REP_MS = 700L

class RepCounter {
    var exercise = Exercise.PUSHUPS
        set(v) { field = v; reset() }
    var reps = 0; private set
    var effort = 0f; private set
    var state = State.WAIT; private set
    var countdown = 3; private set
    var message = MSG; private set
    var onRep: ((Exercise) -> Unit)? = null
    val x = FloatArray(33); val y = FloatArray(33); val vis = BooleanArray(33)
    val depth = floatArrayOf(1f, 1f, 1f)   // rep-depth scale per exercise (from Settings)

    private val seenAt = LongArray(33)
    private var side = 0
    private var readySince = 0L; private var lostSince = 0L; private var badSince = 0L; private var cdStart = 0L; private var leftT = 0L
    private var down = false; private var frozen = false; private var sigSm = 0f
    private var baseSig = 0f; private var baseArm = 1f
    private var topH = 0f; private var hSm = 0f; private var lastT = 0L; private var wBase = 0f
    private val samples = ArrayList<FloatArray>()

    fun reset() { reps = 0; toWait(MSG) }

    private fun toWait(msg: String) {
        state = State.WAIT; effort = 0f; down = false; frozen = false; leftT = 0; readySince = 0; badSince = 0; message = msg
    }

    /** conf = smoothed k-NN class confidences (0..10) from PoseKnn, or null if the samples file isn't installed. */
    @Suppress("UNUSED_PARAMETER")
    fun update(pose: Pose, w: Int, h: Int, now: Long, conf: Map<String, Float>? = null) {
        val dtS = if (lastT == 0L) 0f else ((now - lastT) / 1000f).coerceAtMost(0.5f)
        lastT = now
        for (i in 11..28) {
            val l = pose.getPoseLandmark(i)
            if (l != null && l.inFrameLikelihood > SEEN) {
                val fresh = now - seenAt[i] > HOLD
                x[i] = if (fresh) l.position.x else x[i] + (l.position.x - x[i]) * 0.5f
                y[i] = if (fresh) l.position.y else y[i] + (l.position.y - y[i]) * 0.5f
                seenAt[i] = now
            }
            vis[i] = now - seenAt[i] <= HOLD
        }

        val (a, b, c) = exercise.joints
        fun ok(sd: Int) = vis[a + sd] && vis[b + sd] && vis[c + sd]
        val sd = if (ok(side)) side else if (ok(1 - side)) 1 - side else -1
        if (sd < 0) {
            if (lostSince == 0L) lostSince = now
            readySince = 0
            when (state) {
                State.COUNT -> if (now - lostSince > LOST) toWait(MSG) else if (now - lostSince > 700) message = MSG
                State.COUNTDOWN -> if (now - lostSince > 1000) toWait(MSG)
                else -> message = MSG
            }
            return
        }
        lostSince = 0; side = sd
        fun px(i: Int) = x[i + sd]
        fun py(i: Int) = y[i + sd]
        fun avgY(id: Int): Float? { var s = 0f; var n = 0; for (k in 0..1) if (vis[id + k]) { s += y[id + k]; n++ }; return if (n > 0) s / n else null }

        val sit = exercise == Exercise.SITUPS
        val push = exercise == Exercise.PUSHUPS
        val shY = avgY(11) ?: 0f; val wrY = avgY(15) ?: 0f
        val hipY = avgY(23); val kneeY = avgY(25); val ankleY = avgY(27)

        var ang = abs(Math.toDegrees((atan2(py(c) - py(b), px(c) - px(b)) - atan2(py(a) - py(b), px(a) - px(b))).toDouble())).toFloat()
        if (ang > 180f) ang = 360f - ang
        // sit-ups: how high the shoulders are above the hips, relative to body size. ~0 lying, ~1 sitting up.
        // Uses vertical distance only, so it works from the front as well as from the side.
        val shW = if (vis[11] && vis[12]) abs(x[11] - x[12]) else 0f
        val ref = max(max(shW, hypot(px(11) - px(23), py(11) - py(23))), 1f)
        val sitSig = if (hipY != null) (hipY - shY) / ref else 0f
        val sig = if (sit) sitSig else ang
        sigSm = if (state == State.WAIT) sig else sigSm * 0.6f + sig * 0.4f

        // push-up geometry (only used when the k-NN samples file is missing)
        var hs = 0f; var hn = 0
        for (s2 in 0..1) if (vis[11 + s2] && vis[15 + s2]) { hs += y[15 + s2] - y[11 + s2]; hn++ }
        val hh = if (push && hn > 0) hs / hn else 0f
        hSm = if (state == State.WAIT) hh else hSm * 0.6f + hh * 0.4f
        val arm = if (push) hypot(px(11) - px(13), py(11) - py(13)) + hypot(px(13) - px(15), py(13) - py(15)) else 1f
        val reach = max(if (state == State.COUNT) topH else hSm, 10f)
        val ratioLim: Pair<Float, Float>? = when {
            ankleY != null -> (ankleY - shY) / reach to 1.0f
            kneeY != null -> (kneeY - shY) / reach to 0.62f
            hipY != null -> (hipY - shY) / reach to 0.3f
            else -> null
        }
        fun plankLike(t: Float) = ratioLim == null || ratioLim.first < t * ratioLim.second
        wBase = if (state != State.COUNT) wrY else wBase + (wrY - wBase) * (1f - exp(-dtS / 2f))
        val planted = abs(wrY - wBase) < 0.4f * max(topH, 20f)

        // k-NN classes for this exercise (push-ups / squats)
        val prefix = if (push) "pushups" else "squats"
        val knnOn = conf != null && !sit
        val posConf = if (conf != null && !sit) conf.entries.filter { it.key.startsWith(prefix) }.sumOf { it.value.toDouble() }.toFloat() else 0f
        val downConf = conf?.get(prefix + "_down") ?: 0f
        val upConf = conf?.get(prefix + "_up") ?: 0f

        fun standingNow(): Boolean {
            val an = ankleY ?: return false; val hp = hipY ?: return false
            val torso = hp - shY
            return torso > 0f && sitSig > 0.8f && (an - hp) > 1.1f * torso
        }
        fun startHint(): String? = when (exercise) {
            Exercise.PUSHUPS -> if (knnOn) { if (posConf < 5f) "Get down into push-up position" else null } else when {
                hh < 0.2f * arm -> "Put your hands on the floor under your shoulders"
                !plankLike(1.5f) -> "Get down into push-up position"
                else -> null
            }
            Exercise.SITUPS -> if (standingNow()) "Lie down on your back" else null
            Exercise.SQUATS -> if (knnOn) { if (posConf < 5f) "Stand up straight" else null }
                else if (vis[11 + sd] && vis[23 + sd] && abs(py(11) - py(23)) < abs(px(11) - px(23)) * 1.5f) "Stand up straight" else null
        }
        fun brokeForm(): Boolean = when (exercise) {
            Exercise.PUSHUPS -> topH > 0f && (hSm < (if (frozen) 0.25f else 0.12f) * topH || !plankLike(if (frozen) 1.4f else 1.8f) || !planted)
            Exercise.SITUPS -> standingNow()
            Exercise.SQUATS -> false
        }

        when (state) {
            State.WAIT -> {
                val hint = startHint()
                if (hint != null) { readySince = 0; message = hint }
                else {
                    if (readySince == 0L) readySince = now
                    message = "Good, hold that position"
                    if (now - readySince > 600) { state = State.COUNTDOWN; cdStart = now; badSince = 0; samples.clear() }
                }
            }
            State.COUNTDOWN -> {
                val hint = startHint()
                if (hint != null) {
                    if (badSince == 0L) badSince = now
                    if (now - badSince > 1000) { toWait(hint); return }
                } else badSince = 0
                message = "Hold this position"
                val t = now - cdStart
                countdown = (3 - (t / 1000).toInt()).coerceAtLeast(1)
                if (t > 1800) samples.add(floatArrayOf(sigSm, hSm, arm))
                if (t >= 3000) {
                    if (samples.isEmpty()) samples.add(floatArrayOf(sigSm, hSm, arm))
                    fun med(k: Int) = samples.map { it[k] }.sorted()[samples.size / 2]
                    baseSig = med(0); topH = med(1); baseArm = max(med(2), 1f)
                    state = State.COUNT; message = ""; down = false; frozen = false; leftT = 0; effort = 0f
                }
            }
            State.COUNT -> {
                if (knnOn) {   // count by matching real push-up / squat example poses (Google's rep-counting logic)
                    val sc = depth[exercise.ordinal]
                    val enter = max(3f, 6f * sc); val exit = max(2f, 4f * sc)
                    if (posConf < 3f) {   // not in this exercise's position: pause, count nothing
                        frozen = true; effort = 0f; down = false
                        message = if (push) "Get back into push-up position" else "Stand back in front of the camera"
                        return
                    }
                    frozen = false; message = ""
                    effort = effort * 0.5f + (downConf / enter).coerceIn(0f, 1f) * 0.5f
                    if (!down) { if (downConf > enter) { down = true; leftT = now } }
                    else if (downConf < exit && upConf >= 4f) {   // must come back UP to the start pose to count
                        down = false
                        if (now - leftT >= MIN_REP_MS) { reps++; onRep?.invoke(exercise) }
                    }
                    return
                }
                if (brokeForm()) {
                    frozen = true; effort = 0f; down = false; leftT = 0
                    message = if (push) "Get back into push-up position" else "Lie back down to continue"
                    return
                }
                frozen = false; message = ""
                val scale = depth[exercise.ordinal]
                val f: Float
                if (push) {
                    topH = max(topH * (1f - 0.03f * dtS), hSm)
                    f = (topH - hSm) / (0.55f * max(topH, 20f) * scale)
                } else {
                    val diff = if (sit) sigSm - baseSig else abs(sigSm - baseSig)   // sit-ups count going UP from lying
                    f = diff / (exercise.range * scale)
                }
                effort = effort * 0.4f + f.coerceIn(0f, 1f) * 0.6f
                if (!down) {
                    if (sit) { baseSig = if (sigSm < baseSig) sigSm else baseSig + (sigSm - baseSig) * 0.004f }   // lying = lowest point
                    else if (effort < 0.2f) baseSig += (sigSm - baseSig) * 0.02f
                    if (effort > 0.2f && leftT == 0L) leftT = now
                    if (effort < 0.1f) leftT = 0
                    if (effort > DOWN_AT) down = true
                } else if (effort < UP_AT) {
                    down = false
                    if (leftT != 0L && now - leftT >= MIN_REP_MS) { reps++; onRep?.invoke(exercise) }
                    leftT = 0
                }
            }
        }
    }
}
